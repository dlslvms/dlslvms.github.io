<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class IdType extends Model
{
    protected $table = 'id_types';
    public $timestamps = false;
}
