@extends('layouts.layout')

@section('content')
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h2 class="page-header"><i class="fa fa-bar-chart-o fa-fw"></i>Statistics Report</h2>
        </div>
    </div>
    @include('page.message')   
    <div class="row">
        <div class="col-md-6 col-md-offset-2">
            <div class="" id="columnchart" style="width:800px; height:500px;"></div>
        </div>
        <!-- /.panel-body -->
    </div>
    <!-- /.panel -->    
</div>
@endsection
@section('scripts')
    
    <script type="text/javascript">
        var analytics = {!!$visitor!!}
        google.charts.load('current', {'packages':['corechart', 'bar'   ]});
      google.charts.setOnLoadCallback(drawChart);

        function drawChart()
        {
            var data = new google.visualization.arrayToDataTable(analytics);
            
            var options = {
                legend: { position: 'right' },
                chart: {
                    title: 'Number of new Registered Visitor per Month',
                    subtitle: 'popularity by percentage',
                    type: 'datetime',
                }, 
                axes: {
                    x: {
                    0: { side: 'bottom', label: ' '} // Top x-axis.
                    }
                },
                bar: { 
                    groupWidth: "20%" 
                },
                
            };
            // var options = 
            // {
            //     title : 'Number of Visitor per Month',
            // };
            var chart = new google.charts.Bar(document.getElementById('columnchart'));
            chart.draw(data, google.charts.Bar.convertOptions(options));
        }  
    </script>
@endsection

