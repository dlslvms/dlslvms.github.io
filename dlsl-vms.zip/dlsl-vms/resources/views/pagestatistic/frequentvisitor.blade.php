@extends('layouts.layout')

@section('content')
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h2 class="page-header"><i class="fa fa-bar-chart-o fa-fw"></i>Statistics Report</h2>
        </div>
    </div>
    @include('page.message')   
    <div class="row">
        <div class="col-md-6 col-md-offset-1">
            <div id="curve_chart" style="width:800px; height:500px;"></div>
        </div>
        <!-- /.panel-body -->
    </div>
    <!-- /.panel -->    
</div>
@endsection
@section('scripts')

    @extends('layouts.statistics')

    <script type="text/javascript">
        var analytics = <?php echo $firstname; ?>

        google.charts.load('current', {'packages':['corechart']});
        google.charts.setOnLoadCallback(drawChart);

    function drawChart()
    {
        var data = google.visualization.arrayToDataTable(analytics);
        var options = 
        {
            title : '',
        };
        var chart = new google.visualization.LineChart(document.getElementById('curve_chart'));
        chart.draw(data, options);  
    }
    </script>
@endsection