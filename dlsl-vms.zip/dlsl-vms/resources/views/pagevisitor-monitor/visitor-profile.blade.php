{{--  @extends('layouts.layout')

@section('content')
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
             <h2 class="page-header"><i class="fa fa-search fa-fw"></i>Visitor Profile</h2>
        </div>
    </div>
    @include('page.message')
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <img src="{{asset('storage/uploads/pictures/'.$visitors->picture.'')}}" style="width: 150px; height: 150px; float:left; border-radius:50%; margin-right:25px;">
            <h2>{{$visitors->firstname}} {{$visitors->middlename}} {{$visitors->lastname}}</h2>
        </div>       
        <!-- /.panel-body -->
    </div>
</div>
@endsection  --}}

@extends('layouts.layout')

@section('content')
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
             <h2 class="page-header"><i class="fa fa-user fa-fw"></i>Visitor Profile</h2>
        </div>
    </div>
    @include('page.message')
    <div class="row">
        <div class="col-md-8 col-md-offset-1 ">   
            <div class="panel panel-success   ">
                <div class="panel-heading">
                    <h3 class="panel-title">{{$visitors->firstname}} {{$visitors->lastname}}</h3>
                </div>
                <div class="panel-body">
                    <div class="row">
                        <div class="col-md-7 col-lg-3 " align="center"> <img src="{{asset('storage/uploads/pictures/'.$visitors->picture.'')}}" style="width: 150px; height: 150px; float:left; border-radius:50%; margin-right:30px;"> </div>
                            <div class=" col-md-9 col-lg-9 "> 
                                <table class="table table-user-information">
                                    <tbody>
                                        <tr>
                                            <td><label>Name</label></td>
                                            <td>{{$visitors->firstname}} {{$visitors->middlename}} {{$visitors->lastname}}</td>         
                                        </tr>
                                        <tr>
                                            <td><label>Address</label></td>
                                            <td>{{$visitors->address}}</td>
                                        </tr>
                                        <tr>
                                            <td><label>Type of ID & ID Number</label></td>
                                            <td>{{$visitors->id_type}} : {{$visitors->govid_number}}</td>
                                        </tr>
                                        <tr>
                                            <td><label>Destination</label></td>
                                            <td>{{$visitors->destination}}</td>
                                        </tr>
                                        <tr>
                                            <td><label>Purpose</label></td>
                                            <td>{{$visitors->purpose}}</td>
                                        </tr>
                                        <tr>
                                            <td><label>Destination</label></td>
                                            <td>{{$visitors->destination}}</td>
                                        </tr>
                                        <tr>
                                            <td><label>Access Card Number</label></td>
                                            <td>{{$visitors->accesscard_number}}</td>
                                        </tr>
                                        {{--  <tr>
                                            <td><label>Time In</label></td>
                                            <td>{{$visitors->timein_at}}</td>
                                        </tr>
                                        <tr>
                                            <td><label>Time Out</label></td>
                                            <td>{{$visitors->timein_out}}</td>
                                        </tr>
                                        <tr>
                                            <td><label>Group Name</label></td>
                                            <td>{{$visitors->groupname}}</td>
                                        </tr>
                                        <tr>
                                            <td><label>Members</label></td>
                                            <td>{{$visitors->members}}</td>
                                        </tr>  --}}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        {{--  <div class="panel-footer">
                            <span class="pull-right">
                                <button onclick="myFunction()" class="btn btn-md btn-success">Print</button>
                                    <script>
                                        function myFunction() 
                                        {
                                            window.print();
                                        }
                                    </script>
                            </span>
                        </div>  --}}
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
    
