@extends('layouts.layout')

@section('content')
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h2 class="page-header"><i class="fa fa-bullseye fa-fw"></i>Visitor Monitor</h2>
        </div>
    </div>
    @include('page.message')   
    <div class="row">
        <div class="col-md-12">
            <div class="panel-heading">
                @include('pagevisitor-monitor.visitor-monitorSearch')
            </div>   
            <div class="panel-body">   
                @if(isset($visitors))   
                           
                <table width="100%" class="table table-bordered table-hover dataTable" id="visitorTable">
                    @include('pagevisitor-monitor.visitor-monitorTable')
                </table>         
                <div class="pull-left">
                    <div class="dataTables_paginate pull-left" id="visitorPaginate" role="status" aria-live="polite">
                        {!! $visitors->links() !!}                          
                    </div>
                </div>
                <div class="pull-right">
                    <div class="dataTables_info pull-right" id="visitorInfo">
                        Showing {{($visitors->currentpage()-1)*$visitors->perpage()+1}} 
                        -{{(($visitors->currentpage()-1)*$visitors->perpage())+$visitors->count()}} 
                        of {{$visitors->total()}} entries                         
                    </div>
                </div>
                @else
                    <div class="alert text-danger">
                        <h2>{{$message}}</h2>
                    </div> 
                @endif 
            </div>    
            <!-- /.table-responsive -->
        </div>       
        <!-- /.panel-body -->
    </div>
    <!-- /.panel -->    
</div>
@endsection