@extends('layouts.layout')

@section('content')
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h2 class="page-header"><i class="fa fa-list-alt fa-fw"></i>Visitor Record</h2>
        </div>
    </div>
    @include('page.message')  
    <div class="row">
        <div class="col-md-12">
            <div class="panel-heading">
                    @include('pagerecord.searchRecord') 
            </div>   
            <div class="panel-body">   
                @if(isset($visitors))   
                           
                <table width="100%" class="table table-bordered table-hover dataTable" id="recordTable">
                    @include('pagerecord.visitor-recordSearchTable')                                      
                </table>         
                @else
                    <div class="alert text-danger">
                        <h2>{{$message}}</h2>
                    </div> 
                @endif 
            </div>    
            <!-- /.table-responsive -->
        </div>       
        <!-- /.panel-body -->
    </div>
    <!-- /.panel -->    
</div>
<!-- /.col-lg-6 -->
@endsection
@section('scripts')
<script type="text/javascript">
    $(document).ready(function() {
        $('#dateFrom').datepicker({
            todayBtn: "linked",
            autoclose: true,
            todayHighlight: true,
            format: 'yyyy-mm-dd'
        });
        $("#dateFrom").datepicker().datepicker("setDate", new Date());
        $('#dateTo').datepicker({
            todayBtn: "linked",
            autoclose: true,
            todayHighlight: true,
            format: 'yyyy-mm-dd'
        });
        $("#dateTo").datepicker().datepicker("setDate", new Date());
    }); 
</script>
@endsection