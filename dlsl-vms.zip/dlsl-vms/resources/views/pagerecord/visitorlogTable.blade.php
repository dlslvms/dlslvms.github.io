<thead>
    <tr>
        <th class="text-center" style="width: 10px;">No.</th>
        <bold>
        <th class="text-center" style="width: 100px;">Visitor Name</th>
        <th class="text-center" style="width: 60px;" colspan="2">Time In At</th>
        <th class="text-center" style="width: 60px;" colspan="2">Time Out At</th>
        {{-- <th class="text-center" style="width: 65px;">Actions</th> --}}
        </bold>
    </tr>
</thead>

<tbody>
        @foreach($visitorlogs as $index => $visitorlog)
        <tr>
            <td class="text-center">{{$index+$visitorlogs->firstItem()}}</td>
            <td hidden>{{$visitorlog->visitor_id}}</td>
            <td class="text-center">{{$visitorlog->firstname}} {{$visitorlog->middlename}} {{$visitorlog->lastname}}</td>
            <td class="text-align" style="width: 30px;">{{date('F d, y', strtotime($visitorlog->timein_at))}}</td>
            <td class="text-align" style="width: 30px;">{{date('h:i A', strtotime($visitorlog->timein_at))}}</td>
            <td class="text-align" style="width: 30px;">{{$visitorlog->timeout_at ? date('F d, y', strtotime($visitorlog->timeout_at)) : null }}</td>
            <td class="text-align" style="width: 30px;">{{$visitorlog->timeout_at ? date('h:i A', strtotime($visitorlog->timeout_at)) : null }}</td>
            {{-- <td class="text-center"style="inline-block">
                <a href="" class="btn btn-xs btn-primary">
                    <i class="fa fa-eye fa-fw"></i> View
                </a>                                       
            </td> --}}
        </tr>
        @endforeach
    </tbody> 
