<thead>
    <tr>
        <th class="text-center" style="width: 1%;">No.</th>
        <bold>
        <th style="width: 80px;">First Name</th>
        <th style="width: 80px;">Last Name</th>
        <th class="text-center" style="width: 50px;">User ID</th>
        <th class="text-center" style="width: 50px;">User Type</th>
        <th class="text-center" style="width: 50px;" colspan="2">Login At</th>
        <th class="text-center" style="width: 50px;" colspan="2">Logout At</th>
        {{-- <th class="text-center" style="width: 65px;">Actions</th> --}}
        </bold>
    </tr>
</thead>

<tbody>
        @foreach($userlogs as $index => $userlog)
        <tr>
            <td class="text-center">{{$index+$userlogs->firstItem()}}</td>
            <td hidden>{{$userlog->user_id}}</td>
            <td>{{$userlog->firstname}}</td>
            <td>{{$userlog->lastname}}</td>
            <td class="text-center">{{$userlog->user_number}}</td>
            <td class="text-center">{{$userlog->user_type}}</td>
            <td class="text-align" style="width: 30px;">{{date('F d, y', strtotime($userlog->login_at))}}</td>
            <td class="text-align" style="width: 30px;">{{date('h:i A', strtotime($userlog->login_at))}}</td>
            <td class="text-align" style="width: 30px;">{{$userlog->logout_at ? date('F d, y', strtotime($userlog->logout_at)) : null }}</td>
            <td class="text-align" style="width: 30px;">{{$userlog->logout_at ? date('h:i A', strtotime($userlog->logout_at)) : null }}</td>
            {{-- <td class="text-center"style="inline-block">
                <a href="" class="btn btn-xs btn-primary">
                    <i class="fa fa-eye fa-fw"></i> View
                </a>                                       
            </td> --}}
        </tr>
        @endforeach
    </tbody> 
