<thead>
    <tr>
        <th class="text-center" style="width: 1%;">No.</th>
        <bold>
        <th class="text-center" style="width: 100px;">Visitor Name</th>
        <th class="text-center" style="width: 70px;">Destination</th>
        <th class="text-center" style="width: 60px;">Purpose</th>
        <th class="text-center" style="width: 70px;" colspan="2">Time in at</th>
        <th class="text-center" style="width: 70px;" colspan="2">Time out at</th>
        <th class="hidden-print" "text-center" style="width: 75px;">Actions</th>
        </bold>
    </tr>
</thead>

<tbody>
    @foreach($visitors as $index => $visitor)
    <tr>
        <td class="text-center">{{$index + $visitors->firstItem()}} </td>
        <td class="text-center">{{$visitor->firstname}} {{$visitor->lastname}} </td>
        <td class="text-center">{{$visitor->destination}}</td>
        <td class="text-center">{{$visitor->purpose}}</td>
        <td class="text-align" style="width: 30px;">{{date('F d, y', strtotime($visitor->timein_at))}}</td>
        <td class="text-align" style="width: 30px;">{{date('h:i A', strtotime($visitor->timein_at))}}</td>
        <td class="text-align" style="width: 30px;">{{$visitor->timeout_at ? date('F d, y', strtotime($visitor->timeout_at)) : null }}</td>
        <td class="text-align" style="width: 30px;">{{$visitor->timeout_at ? date('h:i A', strtotime($visitor->timeout_at)) : null }}</td>
        <td class="hidden-print" "text-center" style="inline-block">
            <a href="{{route('visitor-monitor.edit', ['id' => $visitor->id])}}" class="btn btn-xs btn-primary">
                <i class="fa fa-pencil-square-o fa-fw"></i> View
            </a>                                  
            {{-- <a href="" class="btn btn-xs btn-warning">
                <i class="fa fa-tag fa-fw"></i> Checkout
            </a>                                   --}}
        </td>
    </tr>
    @endforeach
</tbody> 
    