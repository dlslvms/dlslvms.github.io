@extends('layouts.layout')

@section('content')
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h2 class="page-header"><i class="fa fa-th-list fa-fw"></i>User Logs</h2>
        </div>
    </div>
    @include('page.message')  
    <div class="row">
        <div class="col-md-12">
            <div class="panel-heading">
                    @include('pagerecord.search') 
            </div>  
            <div class="panel-body">   
                @if(isset($userlogs))   
                           
                <table width="100%" class="table table-bordered table-hover dataTable" id="userlogTable">
                    @include('pagerecord.userlogTable')
                                      
                </table>         
                <div class="pull-left">                   
                    <div class="dataTables_paginate pull-left" id="userlogPaginate" role="status" aria-live="polite">
                        {!! $userlogs->links() !!}                         
                    </div>
                </div>
                <div class="pull-right">
                    <div class="dataTables_info pull-right" id="userlogInfo">
                        Showing {{($userlogs->currentpage()-1)*$userlogs->perpage()+1}} 
                        - {{(($userlogs->currentpage()-1)*$userlogs->perpage())+$userlogs->count()}} 
                        of {{$userlogs->total()}} entries                       
                    </div>                    
                </div>
                @else
                    <div class="alert text-danger">
                        <h2>{{$message}}</h2>
                    </div> 
                @endif 
            </div>    
            <!-- /.table-responsive -->
        </div>       
        <!-- /.panel-body -->
    </div>
    <!-- /.panel -->    
</div>
<!-- /.col-lg-6 -->
@endsection
@section('scripts')
<script type="text/javascript">
    $(document).ready(function() {
        $('#dateFrom').datepicker({
            todayBtn: "linked",
            autoclose: true,
            todayHighlight: true,
            format: 'yyyy-mm-dd'
        });
        $("#dateFrom").datepicker().datepicker("setDate", new Date());
        $('#dateTo').datepicker({
            todayBtn: "linked",
            autoclose: true,
            todayHighlight: true,
            format: 'yyyy-mm-dd'
        });
        $("#dateTo").datepicker().datepicker("setDate", new Date());
    }); 
</script>
@endsection