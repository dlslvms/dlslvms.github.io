@extends('layouts.layout')

@section('content')
<div id="page-wrapper">
    <div class="hidden-print""row">
        <div class="col-lg-12">
             <h2 class="page-header"><i class="fa fa-id-badge fa-fw"></i>Print Badge</h2>
        </div>
    </div>

    <div class="row">
        <div class="hidden-print">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-success" >
                <div class="panel-heading">
                    <center><label>Visitor Badge</label>
                </div>
            </div>
        </div>
        </div>
    @include('page.message') 
    <div class="row">
        <div class="col-md-8 col-md-offset-2 ">
            {{-- <div class="panel panel-default"> --}}
                @foreach($visitors as $visitor)
                <div class="panel-body">
                        <div class="col-md-4 col-md-offset-1">
                                <img src="{{asset('storage/uploads/pictures/'.$visitors->picture.'')}}" style="width: 150px; height: 150px; float:left; border-radius:50%; margin-right:25px;"> 
                        </div>
                        <div class="col-md-4 col-md-offset-1">
                            <label>DLSL VISITOR PASS</label>
                            <label>{{$visitors->groupname}}</label><br>  
                            <label>{{$visitors->firstname}} {{$visitors->lastname}}</label><br>        
                            <label>{{$visitors->accesscard_number}}</label><br>   
                            <label>{{$visitors->destination}}</label><br>     
                            <label>{{$visitors->purpose}}</label><br>   
                            <label>{{ Carbon\Carbon::parse($visitors->timein_at)->format('d-m-Y') }}</label>
                        </div>
                </div>
                @endforeach
                <div class="col-md-11 col-md-offset-10">
                    <span class="hidden-print">
                        <button onclick="myFunction()" class="btn btn-md btn-success" >Print</button>
                            <script>
                                function myFunction() 
                                {
                                    window.print();
                                }
                            </script>
                    </span>
                </div>
            {{-- </div> --}}
        </div>
    </div>
</div>   
@endsection