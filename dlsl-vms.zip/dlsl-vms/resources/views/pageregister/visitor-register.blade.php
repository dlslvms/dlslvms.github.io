@extends('layouts.layout')

@section('content')
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h2 class="page-header"><i class="fa fa-fw fa-pencil-square-o"></i>Visitor Registration</h2>
        </div>
    </div>
    @include('page.message') 
    <div class="row">
        <div class="">
            <div class="panel panel-default">
                <div class="panel-body">
                    <form enctype="multipart/form-data" class="" autocomplete="off" role="form" action="{{ route('visitor-register.store') }}" method="POST">
                        {{ csrf_field() }}
                        <fieldset>
                            @include('pageregister.visitor-registerForm')
                        </fieldset>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>   
@endsection
@section('scripts')
<script type="text/javascript">
    // $(document).ready(function () {
    //     $(".text").hide();
    //     $("#registration_type1").click(function () {
    //         $(".text").show();
    //         $(".text1").hide();
    //     });
    //     $(".text1").hide();
    //     $("#registration_type2").click(function () {
    //         $(".text").hide();
    //         $(".text1").show();
    //     });
    // });
    document.getElementById('group_button').addEventListener('click',hideshow);

    function hideshow(e) {
        document.getElementById('hidden-div').style.display = 'block'; 
        this.style.display = 'none';
        e.preventDefault();
    }   
</script>
@endsection