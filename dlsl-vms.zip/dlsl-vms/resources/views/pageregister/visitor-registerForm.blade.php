<div class="row">
    <div class="col-md-3">            
        <div class="form-group">
            <div class="form-group  {{ $errors->has('picture') ? ' has-error' : '' }}">
                <label>Upload Visitor Picture</label>
                <input type="file" name="picture">
                @if ($errors->has('picture'))
                    <span class="help-block">
                        <strong>{{ $errors->first('picture') }}</strong>
                    </span>
                @endif
            </div>
        </div>
    </div>
</div>
<div class="row">                
    <div class="col-md-4 form-group {{ $errors->has('firstname') ? ' has-error' : '' }}">
        <label for="firstname">First name</label>
        <input class="form-control" placeholder="Firstname" id="firstname" name="firstname"  type="text" value="{{old('firstname')}}" autofocus>
        @if ($errors->has('firstname'))
            <span class="help-block">
                <strong>{{ $errors->first('firstname') }}</strong>
            </span>
        @endif
    </div>                            
    <div class="col-md-4 form-group {{ $errors->has('middlename') ? ' has-error' : '' }}">
        <label for="middlename">Middle name</label>
        <input class="form-control" placeholder="Middlename" id="middlename" name="middlename"  type="text" value="{{old('middlename')}}" autofocus>
        @if ($errors->has('middlename'))
            <span class="help-block">
                <strong>{{ $errors->first('middlename') }}</strong>
            </span>
        @endif
    </div>
    <div class="col-md-4 form-group {{ $errors->has('lastname') ? ' has-error' : '' }}">
        <label for="lastname">Last name</label>
        <input class="form-control" placeholder="Lastname" id="lastname" name="lastname"  type="text" value="{{old('lastname')}}" autofocus>
        @if ($errors->has('lastname'))
            <span class="help-block">
                <strong>{{ $errors->first('lastname') }}</strong>
            </span>
        @endif
    </div>  
    <div class="col-md-6 form-group {{ $errors->has('address') ? ' has-error' : '' }}">
        <label for="address">Address</label>
        <input class="form-control" placeholder="Address" id="address" name="address"  type="address" value="{{old('address')}}" autofocus>
        @if ($errors->has('address'))
            <span class="help-block">
                <strong>{{ $errors->first('address') }}</strong>
            </span>
        @endif
    </div>
        <div class="col-md-6 form-group {{ $errors->has('contact_number') ? ' has-error' : '' }}">
        <label for="contact_number">Contact Number</label>
        <input class="form-control" placeholder="Contact Number" id="contact_number" name="contact_number"  type="contact_number" value="{{old('contact_number')}}" autofocus>
        @if ($errors->has('contact_number'))
            <span class="help-block">
                <strong>{{ $errors->first('contact_number') }}</strong>
            </span>
        @endif
    </div>  
    <div class="col-md-6 form-group {{ $errors->has('id_type') ? ' has-error' : '' }}">
        <label for="id_type">ID type</label>
        
        <select class="form-control" id="id_type" name="id_type">
            <option disabled selected hidden>Select ID</option>
            @foreach ($id_types as $index => $id_type)
            <option id="id_type" name="id_type" value="{{$id_type->id}}">{{$id_type->id_type}}</option>
            @endforeach
        
        </select>
        
            @if ($errors->has('id_type'))
                <span class="help-block">
                    <strong>{{ $errors->first('id_type') }}</strong>
                </span>
            @endif
    </div>
    <div class="col-md-6 form-group {{ $errors->has('govid_number') ? ' has-error' : '' }}">
        <label for="govid_number">Governtment ID number</label>
        <input class="form-control" placeholder="Governtment ID number" id="govid_number" name="govid_number" type="text" value="{{old('govid_number')}}" autofocus>
        @if ($errors->has('govid_number'))
            <span class="help-block">
                <strong>{{ $errors->first('govid_number') }}</strong>
            </span>
        @endif
    </div>                            
    <div class="col-md-6 form-group {{ $errors->has('destination') ? ' has-error' : '' }}">
        <label for="destination">Destination</label>
        <select class="form-control" id="destination" name="destination">
            <option disabled selected hidden>Select Destiantion</option>
            @foreach($destinations as $index => $destination)
            <option id="destination" name="destination" value="{{$destination->id}}">{{$destination->destination}}</option>
            @endforeach
        </select>
        @if ($errors->has('destination'))
            <span class="help-block">
                <strong>{{ $errors->first('destination') }}</strong>
            </span>
        @endif
    </div>
    

    <div class="col-md-6 form-group {{ $errors->has('purpose') ? ' has-error' : '' }}">
            <label for="purpose">Purpose</label>
            <select class="form-control" id="purpose" name="purpose">
                <option disabled selected hidden>Puspose</option>
                <option id="purpose" name="purpose" value="Alumni Visit">ALUMNI VISIT</option>
                <option id="purpose" name="purpose" value="Assembly">ASSEMBLY</option>
                <option id="purpose" name="purpose" value="Audience">AUDIENCE</option>
                <option id="purpose" name="purpose" value="Competition">COMPETITION</option>
                <option id="purpose" name="purpose" value="Conference">CONFERENCE</option>
                <option id="purpose" name="purpose" value="Guest Speaker">GUEST SPEAKER</option>
                <option id="purpose" name="purpose" value="Inquiry">INQUIRY/ADMISSION</option>
                <option id="purpose" name="purpose" value="Meeting">MEETING</option>
                <option id="purpose" name="purpose" value="Scholarship">SCHOLARSHIP</option>
                <option id="purpose" name="purpose" value="School Function">SCHOOL FUNCTION</option>
                <option id="purpose" name="purpose" value="Seminar">SEMINAR</option>
                <option id="purpose" name="purpose" value="Survey Visit">SURVEY VISIT</option>
                <option id="purpose" name="purpose" value="Parent-Teacher Conference">PARENT-TEACHER CONFERENCE</option>
                <option id="purpose" name="purpose" value="Visit">VISIT</option>
                <option id="purpose" name="purpose" value="Others">OTHERS</option>
            </select>
            <input type="text" class="form-control" name="purpose" id="purpose">
            @if ($errors->has('purpose'))
                <span class="help-block">
                    <strong>{{ $errors->first('purpose') }}</strong>
                </span>
            @endif
        </div>
    
    <div class="col-md-12 form-group">
        <label for="lastname">Access Card Number</label>
        <input class="form-control" placeholder="Access Card Number" id="accesscard_number" name="accesscard_number"  type="text" value="{{old('accesscard_number')}}" autofocus>
        @if ($errors->has('accesscard_number'))
            <span class="help-block">
                <strong>{{ $errors->first('accesscard_number') }}</strong>
            </span>
        @endif
    </div>
    <div class="col-md-12 form-group hidden-div" id="hidden-div">
        <label for="groupname">Group Name</label>
        <input class="form-control" placeholder="Group Name" id="groupname" name="groupname" rows="3" type="text" value="" autofocus>
        <br><label for="members">Members</label>
        <textarea class="form-control" placeholder="Members" id="members" name="members" rows="3" value=""></textarea>
    </div>    
</div>

<div class="pull-left">
        <span style="display:block;">
            <button class="btn btn-md btn-primary" name="group_button" id="group_button"><i class="fa fa-fw fa-users"></i> Register Group</button>
        </span>
    </div>
<div class="pull-right">
    <button type="submit" class=" btn btn-md btn-success">Register</button>
    <a href="{{route('visitor-register.index')}}" class=" btn btn-md btn-danger">Cancel</a>
</div>