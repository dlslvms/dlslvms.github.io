@extends('layouts.layout')

@section('title', 'Add User')
@section('content')

<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
             <h2 class="page-header"><i class="fa fa-fw fa-plus-circle"></i>Add User</h2>
        </div>
    </div>
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title"><strong>Registration Form</strong></h3>
                </div>
                <div class="panel-body form-group">
                    <form class="" role="form" method="POST" action="{{ route('user-management.store') }}">
                        {{ csrf_field() }}
                        <fieldset>
                            <br>
                            <div class="col-md-4 form-group {{ $errors->has('lastname') ? ' has-error' : '' }}">
                                <label for="lastname">Last Name</label>
                                <input class="form-control" placeholder="Last Name" id="lastname" name="lastname"  type="text" value="{{old('lastname')}}" autofocus>
                                @if ($errors->has('lastname'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('lastname') }}</strong>
                                    </span>
                                @endif
                            </div>
                            
                            <div class="col-md-4 form-group {{ $errors->has('middlename') ? ' has-error' : '' }}">
                                <label for="middlename">Middle Name</label>
                                <input class="form-control" placeholder="Middle Name" id="middlename" name="middlename"  type="text" value="{{old('middlename')}}" autofocus>
                                @if ($errors->has('middlename'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('middlename') }}</strong>
                                    </span>
                                @endif
                            </div>
                            <div class="col-md-4 form-group {{ $errors->has('firstname') ? ' has-error' : '' }}">
                                <label for="firstname">First Name</label>
                                <input class="form-control" placeholder="First Name" id="firstname" name="firstname"  type="text" value="{{old('firstname')}}" autofocus>
                                @if ($errors->has('firstname'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('firstname') }}</strong>
                                    </span>
                                @endif
                            </div>
                            <br><br><br>
                            <div class="col-md-6 form-group {{ $errors->has('address') ? ' has-error' : '' }}">
                                <label for="address">Address</label>
                                <input class="form-control" placeholder="Address" id="address" name="address"  type="text" value="{{old('address')}}" autofocus>
                                @if ($errors->has('address'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('address') }}</strong>
                                    </span>
                                @endif
                            </div>
                            <div class="col-md-6 form-group {{ $errors->has('birthday') ? ' has-error' : '' }}">
                                <label for="birthday">Birthday</label>
                                <input class="form-control" placeholder="YY-MM-DD" id="birthday" name="birthday"  type="text" value="{{old('birthday')}}" autofocus>
                                @if ($errors->has('birthday'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('birthday') }}</strong>
                                    </span>
                                @endif
                            </div>
                            <br><br><br>
                            <div class="col-md-6 form-group {{ $errors->has('contact_number') ? ' has-error' : '' }}">
                                <label for="contact_number">Contact Number</label>
                                <input class="form-control" placeholder="Contact Number" id="contact_number" name="contact_number"  type="text" value="{{old('contact_number')}}" autofocus>
                                @if ($errors->has('contact_number'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('contact_number') }}</strong>
                                    </span>
                                @endif
                            </div>
                            <div class="col-md-6 form-group {{ $errors->has('user_number') ? ' has-error' : '' }}">
                                <label for="address">Address</label>
                                <input class="form-control"  placeholder="User Number" id="user_number" name="user_number" type="text" value="{{old('user_number')}}" autofocus>
                                @if ($errors->has('user_number'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('user_number') }}</strong>
                                    </span>
                                @endif
                            </div>
                            <br>
                            <div class="col-md-offset-3 form-group {{ $errors->has('user_type') ? ' has-error' : '' }}">
                                <label for="user_type">User Type</label>
                                <label for="user_type">Access Type</label>
                                    <label class="radio-inline">
                                        <input type="radio" name="user_type" id="user_type1" value="admin">Admin
                                    </label>
                                    <label class="radio-inline">
                                        <input type="radio" name="user_type" id="user_type2" value="user">Lobby Guard
                                    </label>
                                @if ($errors->has('user_type'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('user_type') }}</strong>
                                    </span>
                                @endif
                            </div>
                            <div class="col-md-6 form-group {{ $errors->has('password') ? ' has-error' : '' }}">
                                <label for="password">Password</label>
                                <input class="form-control" placeholder="Password" name="password" type="password" value="">
                                @if ($errors->has('password'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('password') }}</strong>
                                    </span>
                                @endif
                            </div>
                            <div class="col-md-6 form-group {{ $errors->has('password_confirmation') ? ' has-error' : '' }}">
                                <label for="password_confirmation">Confirm Password</label>
                                <input class="form-control" placeholder="Confirm Password" name="password_confirmation" type="password" value="">
                                @if ($errors->has('password_confirmation'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('password_confirmation') }}</strong>
                                    </span>
                                @endif
                            </div>
                            <button type="submit" class="btn btn-md btn-success btn-block">Register</button>
                        </fieldset>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection