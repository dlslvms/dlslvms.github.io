@extends('layouts.layout')

@section('title','Edit')
@section('content')
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
             <h2 class="page-header"><i class="fa fa-pencil fa-fw"></i>Edit User</h2>
        </div>
    </div>
    @include('page.message')
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title"><label>Edit Form</label></h3>
                </div>
                @if(isset($users))
                <div class="panel-body">
                    <form class="" role="form" method="POST" action="{{route('user-management.update', ['id' => $users->id])}}">
                        {{method_field('PUT')}}
                        {{ csrf_field() }}
                        <fieldset>
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <div class="form-group">
                                            <label>Upload Visitor Picture</label>
                                            <input type="file" name="picture">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4 form-group">
                                    <label for="lastname">Last Name</label>
                                    <input class="form-control" name="lastname" id="lastname" type="text" placeholder="" 
                                    value="{{$users->lastname}}">                            
                                </div> 
                                
                                <div class="col-md-4 form-group">
                                    <label for="firstname">First Name</label>
                                    <input class="form-control" name="firstname" id="firstname" type="text" placeholder="" 
                                    value="{{$users->firstname}}">                            
                                </div>
                                
                                <div class="col-md-4 form-group">
                                    <label for="middlename">Middle Name</label>
                                    <input class="form-control" name="middlename" id="middlename" type="text" placeholder="" 
                                    value="{{$users->lastname}}">                            
                                </div>
                                
                                <div class="col-md-4 form-group">
                                    <label for="address">Address</label>
                                    <input class="form-control" name="address" id="address" type="text" placeholder="" 
                                    value="{{$users->address}}">                            
                                </div>
                                
                                <div class="col-md-4 form-group">
                                    <label for="birthday">Birthday</label>
                                    <input class="form-control" name="birthday" id="birthday" type="text" placeholder="" 
                                    value="{{$users->birthday}}">                            
                                </div>
                                
                                <div class="col-md-4 form-group">
                                    <label for="contact_number">Contact Number</label>
                                    <input class="form-control" name="contact_number" id="contact_number" type="text" placeholder="" 
                                    value="{{$users->contact_number}}">                            
                                </div>

                                <div class="col-md-6 form-group">
                                    <label for="user_number">User ID Number</label>
                                    <input class="form-control" name="user_number" id="user_number" type="text" placeholder="" 
                                    value="{{$users->user_number}}">                            
                                </div>  
                                
                                <div class="col-md-6">              
                                    <div class="form-group {{ $errors->has('user_type') ? ' has-error' : '' }}">
                                            <br><br><label for="user_type">Access Type</label>
                                            <label class="radio-inline">
                                                <input type="radio" name="user_type" id="user_type" value="admin" {{ $users->user_type == 'admin' ? 'checked' : '' }}>Admin                                             
                                            </label>            
                                            <label class="radio-inline">
                                                <input type="radio" name="user_type" id="user_type" value="user" {{ $users->user_type == 'user' ? 'checked' : '' }}>Lobby Guard                                            
                                            </label>
                                            @if ($errors->has('user_type'))
                                                <span class="help-block">
                                                    <strong>{{ $errors->first('user_type') }}</strong>
                                                </span>
                                            @endif
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <label for="password">Change Password</label>
                                    <div class="form-group {{ $errors->has('password') ? ' has-error' : '' }}">
                                        <input class="form-control" placeholder="New Password" name="password" type="password">
                                        @if ($errors->has('password'))
                                            <span class="help-block">
                                                <strong>{{ $errors->first('password') }}</strong>
                                            </span>
                                        @endif
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <label for="password">Confirm Password</label>
                                    <div class="form-group {{ $errors->has('password_confirmation') ? ' has-error' : '' }}">
                                        <input class="form-control" placeholder="Confirm New Password" name="password_confirmation" type="password" value="">
                                        @if ($errors->has('password_confirmation'))
                                            <span class="help-block">
                                                <strong>{{ $errors->first('password_confirmation') }}</strong>
                                            </span>
                                        @endif
                                    </div>
                                </div>

                                <div class="pull-right">
                                    <button type="submit" class=" btn btn-md btn-success">Save</button>
                                    <a href="{{route('visitor-register.index')}}" class=" btn btn-md btn-danger">Cancel</a>
                                </div>
                        </fieldset>
                    </form>
                </div>
                @endif
            </div>
        </div>
    </div>
</div>
@endsection