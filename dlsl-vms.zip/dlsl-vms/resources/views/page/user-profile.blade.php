@extends('layouts.layout')

@section('content')
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
             <h2 class="page-header"><i class="fa fa-user fa-fw"></i>User Profile</h2>
        </div>
    </div>
    @include('page.message')
    <div class="row">
        <div class="col-md-10 col-md-offset-1 ">   
            <div class="panel panel-success   ">
                <div class="panel-heading">
                    <h3 class="panel-title">{{$user->firstname}} {{$user->lastname}}</h3>
                </div>
                <div class="panel-body">
                    <div class="row">
                        <div class="col-md-7 col-lg-3 " align="center"> <img src="{{asset('storage/uploads/pictures/'.$user->avatar.'')}}" style="width: 150px; height: 150px; float:left; border-radius:50%; margin-right:30px;"> </div>
                            <div class=" col-md-9 col-lg-9 "> 
                                <table class="table table-user-information">
                                    <tbody>
                                        <tr>
                                            <td><label>First Name</label></td>
                                            <td>{{$user->firstname}}</td>         
                                        </tr>
                                        <tr>
                                            <td><label>Middle Name</label></td>
                                            <td>{{$user->middlename}}</td>         
                                        </tr>
                                        <tr>
                                            <td><label>Last Name</label></td>
                                            <td>{{$user->lastname}}</td>         
                                        </tr>
                                        <tr>
                                            <td><label>Address</label></td>
                                            <td>{{$user->address}}</td>
                                        </tr>
                                        <tr>
                                            <td><label>Birthday</label></td>
                                            <td>{{$user->birthday}}</td>
                                        </tr>
                                        <tr>
                                            <td><label>Contact Number</label></td>
                                            <td>{{$user->contact_number}}</td>
                                        </tr>
                                        <tr>
                                            <td><label>User Number</label></td>
                                            <td>{{$user->user_number}}</td>
                                        </tr>
                                        <tr>
                                            <td><label>User Type</label></td>
                                            <td>{{$user->user_type}}</td>
                                        </tr>
                                    </tbody>
                                </table>                                
                            </div>
                        </div>
                        <div class="panel-footer">
                            <span class="pull-right">
                                {{-- <button onclick="myFunction()" class="btn btn-md btn-success">Print</button>
                                <script>
                                    function myFunction() 
                                    {
                                        window.print();
                                    }
                                </script> --}}
                                <a href="{{route('user-management.edit', ['id' => $user->id])}}" data-original-title="Edit this user" data-toggle="tooltip" type="button" class="btn btn-md btn-success">Edit<i class="glyphicon glyphicon"></i></a>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection 