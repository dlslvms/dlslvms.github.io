<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h2 class="page-header"><i class="fa fa-bullseye fa-fw"></i>Visitor Monitor</h2>
        </div>
    </div>
    <?php echo $__env->make('page.message', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>   
    <div class="row">
        <div class="col-md-12">
            <div class="panel-heading">
                <?php echo $__env->make('pagevisitor-monitor.visitor-monitorSearch', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>   
            <div class="panel-body">   
                <?php if(isset($visitors)): ?>   
                           
                <table width="100%" class="table table-bordered table-hover dataTable" id="visitorTable">
                    <?php echo $__env->make('pagevisitor-monitor.visitor-monitorTable', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </table>         
                <div class="pull-left">
                    <div class="dataTables_paginate pull-left" id="visitorPaginate" role="status" aria-live="polite">
                        <?php echo $visitors->links(); ?>                          
                    </div>
                </div>
                <div class="pull-right">
                    <div class="dataTables_info pull-right" id="visitorInfo">
                        Showing <?php echo e(($visitors->currentpage()-1)*$visitors->perpage()+1); ?> 
                        -<?php echo e((($visitors->currentpage()-1)*$visitors->perpage())+$visitors->count()); ?> 
                        of <?php echo e($visitors->total()); ?> entries                         
                    </div>
                </div>
                <?php else: ?>
                    <div class="alert text-danger">
                        <h2><?php echo e($message); ?></h2>
                    </div> 
                <?php endif; ?> 
            </div>    
            <!-- /.table-responsive -->
        </div>       
        <!-- /.panel-body -->
    </div>
    <!-- /.panel -->    
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>