<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
             <h2 class="page-header"><i class="fa fa-user fa-fw"></i>User Profile</h2>
        </div>
    </div>
    <?php echo $__env->make('page.message', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="row">
        <div class="col-md-10 col-md-offset-1 ">   
            <div class="panel panel-success   ">
                <div class="panel-heading">
                    <h3 class="panel-title"><?php echo e($user->firstname); ?> <?php echo e($user->lastname); ?></h3>
                </div>
                <div class="panel-body">
                    <div class="row">
                        <div class="col-md-7 col-lg-3 " align="center"> <img src="<?php echo e(asset('storage/uploads/pictures/'.$user->avatar.'')); ?>" style="width: 150px; height: 150px; float:left; border-radius:50%; margin-right:30px;"> </div>
                            <div class=" col-md-9 col-lg-9 "> 
                                <table class="table table-user-information">
                                    <tbody>
                                        <tr>
                                            <td><label>First Name</label></td>
                                            <td><?php echo e($user->firstname); ?></td>         
                                        </tr>
                                        <tr>
                                            <td><label>Middle Name</label></td>
                                            <td><?php echo e($user->middlename); ?></td>         
                                        </tr>
                                        <tr>
                                            <td><label>Last Name</label></td>
                                            <td><?php echo e($user->lastname); ?></td>         
                                        </tr>
                                        <tr>
                                            <td><label>Address</label></td>
                                            <td><?php echo e($user->address); ?></td>
                                        </tr>
                                        <tr>
                                            <td><label>Birthday</label></td>
                                            <td><?php echo e($user->birthday); ?></td>
                                        </tr>
                                        <tr>
                                            <td><label>Contact Number</label></td>
                                            <td><?php echo e($user->contact_number); ?></td>
                                        </tr>
                                        <tr>
                                            <td><label>User Number</label></td>
                                            <td><?php echo e($user->user_number); ?></td>
                                        </tr>
                                        <tr>
                                            <td><label>User Type</label></td>
                                            <td><?php echo e($user->user_type); ?></td>
                                        </tr>
                                    </tbody>
                                </table>                                
                            </div>
                        </div>
                        <div class="panel-footer">
                            <span class="pull-right">
                                
                                <a href="<?php echo e(route('user-management.edit', ['id' => $user->id])); ?>" data-original-title="Edit this user" data-toggle="tooltip" type="button" class="btn btn-md btn-success">Edit<i class="glyphicon glyphicon"></i></a>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>