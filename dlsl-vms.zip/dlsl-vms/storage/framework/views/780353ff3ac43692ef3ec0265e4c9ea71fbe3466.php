<div class="row">
    <div class="col-md-3">            
        <div class="form-group">
            <div class="form-group  <?php echo e($errors->has('picture') ? ' has-error' : ''); ?>">
                <label>Upload Visitor Picture</label>
                <input type="file" name="picture">
                <?php if($errors->has('picture')): ?>
                    <span class="help-block">
                        <strong><?php echo e($errors->first('picture')); ?></strong>
                    </span>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<div class="row">                
    <div class="col-md-4 form-group <?php echo e($errors->has('firstname') ? ' has-error' : ''); ?>">
        <label for="firstname">First name</label>
        <input class="form-control" placeholder="Firstname" id="firstname" name="firstname"  type="text" value="<?php echo e(old('firstname')); ?>" autofocus>
        <?php if($errors->has('firstname')): ?>
            <span class="help-block">
                <strong><?php echo e($errors->first('firstname')); ?></strong>
            </span>
        <?php endif; ?>
    </div>                            
    <div class="col-md-4 form-group <?php echo e($errors->has('middlename') ? ' has-error' : ''); ?>">
        <label for="middlename">Middle name</label>
        <input class="form-control" placeholder="Middlename" id="middlename" name="middlename"  type="text" value="<?php echo e(old('middlename')); ?>" autofocus>
        <?php if($errors->has('middlename')): ?>
            <span class="help-block">
                <strong><?php echo e($errors->first('middlename')); ?></strong>
            </span>
        <?php endif; ?>
    </div>
    <div class="col-md-4 form-group <?php echo e($errors->has('lastname') ? ' has-error' : ''); ?>">
        <label for="lastname">Last name</label>
        <input class="form-control" placeholder="Lastname" id="lastname" name="lastname"  type="text" value="<?php echo e(old('lastname')); ?>" autofocus>
        <?php if($errors->has('lastname')): ?>
            <span class="help-block">
                <strong><?php echo e($errors->first('lastname')); ?></strong>
            </span>
        <?php endif; ?>
    </div>  
    <div class="col-md-6 form-group <?php echo e($errors->has('address') ? ' has-error' : ''); ?>">
        <label for="address">Address</label>
        <input class="form-control" placeholder="Address" id="address" name="address"  type="address" value="<?php echo e(old('address')); ?>" autofocus>
        <?php if($errors->has('address')): ?>
            <span class="help-block">
                <strong><?php echo e($errors->first('address')); ?></strong>
            </span>
        <?php endif; ?>
    </div>
        <div class="col-md-6 form-group <?php echo e($errors->has('contact_number') ? ' has-error' : ''); ?>">
        <label for="contact_number">Contact Number</label>
        <input class="form-control" placeholder="Contact Number" id="contact_number" name="contact_number"  type="contact_number" value="<?php echo e(old('contact_number')); ?>" autofocus>
        <?php if($errors->has('contact_number')): ?>
            <span class="help-block">
                <strong><?php echo e($errors->first('contact_number')); ?></strong>
            </span>
        <?php endif; ?>
    </div>  
    <div class="col-md-6 form-group <?php echo e($errors->has('id_type') ? ' has-error' : ''); ?>">
        <label for="id_type">ID type</label>
        
        <select class="form-control" id="id_type" name="id_type">
            <option disabled selected hidden>Select ID</option>
            <?php $__currentLoopData = $id_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $id_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option id="id_type" name="id_type" value="<?php echo e($id_type->id); ?>"><?php echo e($id_type->id_type); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        </select>
        
            <?php if($errors->has('id_type')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('id_type')); ?></strong>
                </span>
            <?php endif; ?>
    </div>
    <div class="col-md-6 form-group <?php echo e($errors->has('govid_number') ? ' has-error' : ''); ?>">
        <label for="govid_number">Governtment ID number</label>
        <input class="form-control" placeholder="Governtment ID number" id="govid_number" name="govid_number" type="text" value="<?php echo e(old('govid_number')); ?>" autofocus>
        <?php if($errors->has('govid_number')): ?>
            <span class="help-block">
                <strong><?php echo e($errors->first('govid_number')); ?></strong>
            </span>
        <?php endif; ?>
    </div>                            
    <div class="col-md-6 form-group <?php echo e($errors->has('destination') ? ' has-error' : ''); ?>">
        <label for="destination">Destination</label>
        <select class="form-control" id="destination" name="destination">
            <option disabled selected hidden>Select Destiantion</option>
            <?php $__currentLoopData = $destinations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $destination): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option id="destination" name="destination" value="<?php echo e($destination->id); ?>"><?php echo e($destination->destination); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php if($errors->has('destination')): ?>
            <span class="help-block">
                <strong><?php echo e($errors->first('destination')); ?></strong>
            </span>
        <?php endif; ?>
    </div>
    

    <div class="col-md-6 form-group <?php echo e($errors->has('purpose') ? ' has-error' : ''); ?>">
            <label for="purpose">Purpose</label>
            <select class="form-control" id="purpose" name="purpose">
                <option disabled selected hidden>Puspose</option>
                <option id="purpose" name="purpose" value="Alumni Visit">ALUMNI VISIT</option>
                <option id="purpose" name="purpose" value="Assembly">ASSEMBLY</option>
                <option id="purpose" name="purpose" value="Audience">AUDIENCE</option>
                <option id="purpose" name="purpose" value="Competition">COMPETITION</option>
                <option id="purpose" name="purpose" value="Conference">CONFERENCE</option>
                <option id="purpose" name="purpose" value="Guest Speaker">GUEST SPEAKER</option>
                <option id="purpose" name="purpose" value="Inquiry">INQUIRY/ADMISSION</option>
                <option id="purpose" name="purpose" value="Meeting">MEETING</option>
                <option id="purpose" name="purpose" value="Scholarship">SCHOLARSHIP</option>
                <option id="purpose" name="purpose" value="School Function">SCHOOL FUNCTION</option>
                <option id="purpose" name="purpose" value="Seminar">SEMINAR</option>
                <option id="purpose" name="purpose" value="Survey Visit">SURVEY VISIT</option>
                <option id="purpose" name="purpose" value="Parent-Teacher Conference">PARENT-TEACHER CONFERENCE</option>
                <option id="purpose" name="purpose" value="Visit">VISIT</option>
                <option id="purpose" name="purpose" value="Others">OTHERS</option>
            </select>
            <input type="text" class="form-control" name="purpose" id="purpose">
            <?php if($errors->has('purpose')): ?>
                <span class="help-block">
                    <strong><?php echo e($errors->first('purpose')); ?></strong>
                </span>
            <?php endif; ?>
        </div>
    
    <div class="col-md-12 form-group">
        <label for="lastname">Access Card Number</label>
        <input class="form-control" placeholder="Access Card Number" id="accesscard_number" name="accesscard_number"  type="text" value="<?php echo e(old('accesscard_number')); ?>" autofocus>
        <?php if($errors->has('accesscard_number')): ?>
            <span class="help-block">
                <strong><?php echo e($errors->first('accesscard_number')); ?></strong>
            </span>
        <?php endif; ?>
    </div>
    <div class="col-md-12 form-group hidden-div" id="hidden-div">
        <label for="groupname">Group Name</label>
        <input class="form-control" placeholder="Group Name" id="groupname" name="groupname" rows="3" type="text" value="" autofocus>
        <br><label for="members">Members</label>
        <textarea class="form-control" placeholder="Members" id="members" name="members" rows="3" value=""></textarea>
    </div>    
</div>

<div class="pull-left">
        <span style="display:block;">
            <button class="btn btn-md btn-primary" name="group_button" id="group_button"><i class="fa fa-fw fa-users"></i> Register Group</button>
        </span>
    </div>
<div class="pull-right">
    <button type="submit" class=" btn btn-md btn-success">Register</button>
    <a href="<?php echo e(route('visitor-register.index')); ?>" class=" btn btn-md btn-danger">Cancel</a>
</div>