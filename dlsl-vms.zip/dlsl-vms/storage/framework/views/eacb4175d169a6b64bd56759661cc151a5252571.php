<thead>
    <tr>
        <th class="text-center" style="width: 1%;">No.</th>
        <bold>
        <th class="text-center" style="width: 100px;">Visitor Name</th>
        <th class="text-center" style="width: 70px;">Destination</th>
        <th class="text-center" style="width: 60px;">Purpose</th>
        <th class="text-center" style="width: 60px;">Access Card No.</th>
        <th class="text-center" style="width: 70px;">Time in</th>
        <th class="text-center" style="width: 70px;">Time out</th>
        <th class="hidden-print" "text-center" style="width: 75px;">Actions</th>
        </bold>
    </tr>
</thead>
<tbody>
    <?php $__currentLoopData = $visitors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $visitor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td class="text-center"><?php echo e($index + $visitors->firstItem()); ?> </td>
        <td class="text-center"><?php echo e($visitor->firstname); ?> <?php echo e($visitor->lastname); ?> </td>
        <td class="text-center"><?php echo e($visitor->destination); ?></td>
        <td class="text-center"><?php echo e($visitor->purpose); ?></td>
        <td class="text-center"><?php echo e($visitor->accesscard_number); ?></td>
        <td class="text-center"><?php echo e($visitor->timein_at ? date('h:i A', strtotime($visitor->timein_at)) : null); ?></td>
        <td class="text-center"><?php echo e($visitor->timeout_at ? date('h:i A', strtotime($visitor->timeout_at)) : null); ?></td>
        <td class="hidden-print" "text-center"style="inline-block">
            
            <a href="" class="btn btn-xs btn-warning">
                <i class="fa fa-tag fa-fw"></i> Checkout
            </a>  
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   
</tbody> 
    