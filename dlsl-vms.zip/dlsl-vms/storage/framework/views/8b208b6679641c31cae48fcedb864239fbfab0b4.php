<thead>
    <tr>
        <th class="text-center" style="width: 10px;">No.</th>
        <bold>
        <th class="text-center" style="width: 100px;">Visitor Name</th>
        <th class="text-center" style="width: 60px;" colspan="2">Time In At</th>
        <th class="text-center" style="width: 60px;" colspan="2">Time Out At</th>
        
        </bold>
    </tr>
</thead>

<tbody>
        <?php $__currentLoopData = $visitorlogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $visitorlog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="text-center"><?php echo e($index+$visitorlogs->firstItem()); ?></td>
            <td hidden><?php echo e($visitorlog->visitor_id); ?></td>
            <td class="text-center"><?php echo e($visitorlog->firstname); ?> <?php echo e($visitorlog->middlename); ?> <?php echo e($visitorlog->lastname); ?></td>
            <td class="text-align" style="width: 30px;"><?php echo e(date('F d, y', strtotime($visitorlog->timein_at))); ?></td>
            <td class="text-align" style="width: 30px;"><?php echo e(date('h:i A', strtotime($visitorlog->timein_at))); ?></td>
            <td class="text-align" style="width: 30px;"><?php echo e($visitorlog->timeout_at ? date('F d, y', strtotime($visitorlog->timeout_at)) : null); ?></td>
            <td class="text-align" style="width: 30px;"><?php echo e($visitorlog->timeout_at ? date('h:i A', strtotime($visitorlog->timeout_at)) : null); ?></td>
            
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody> 
