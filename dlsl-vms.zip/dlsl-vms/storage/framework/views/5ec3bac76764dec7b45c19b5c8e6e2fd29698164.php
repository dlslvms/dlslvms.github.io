<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
    <div class="hidden-print""row">
        <div class="col-lg-12">
             <h2 class="page-header"><i class="fa fa-id-badge fa-fw"></i>Print Badge</h2>
        </div>
    </div>

    <div class="row">
        <div class="hidden-print">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-success" >
                <div class="panel-heading">
                    <center><label>Visitor Badge</label>
                </div>
            </div>
        </div>
        </div>
    <?php echo $__env->make('page.message', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
    <div class="row">
        <div class="col-md-8 col-md-offset-2 ">
            
                <?php $__currentLoopData = $visitors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $visitor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="panel-body">
                        <div class="col-md-4 col-md-offset-1">
                                <img src="<?php echo e(asset('storage/uploads/pictures/'.$visitors->picture.'')); ?>" style="width: 150px; height: 150px; float:left; border-radius:50%; margin-right:25px;"> 
                        </div>
                        <div class="col-md-4 col-md-offset-1">
                            <label>DLSL VISITOR PASS</label>
                            <label><?php echo e($visitors->groupname); ?></label><br>  
                            <label><?php echo e($visitors->firstname); ?> <?php echo e($visitors->lastname); ?></label><br>        
                            <label><?php echo e($visitors->accesscard_number); ?></label><br>   
                            <label><?php echo e($visitors->destination); ?></label><br>     
                            <label><?php echo e($visitors->purpose); ?></label><br>   
                            <label><?php echo e($visitors->destination->destination); ?></label><br>
                            <label><?php echo e(Carbon\Carbon::parse($visitors->timein_at)->format('d-m-Y')); ?></label>
                        </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-11 col-md-offset-10">
                    <span class="hidden-print">
                        <button onclick="myFunction()" class="btn btn-md btn-success" >Print</button>
                            <script>
                                function myFunction() 
                                {
                                    window.print();
                                }
                            </script>
                    </span>
                </div>
            
        </div>
    </div>
</div>   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>