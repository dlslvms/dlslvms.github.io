<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h2 class="page-header"><i class="fa fa-list-alt fa-fw"></i>Visitor Records</h2>
        </div>
    </div>
    <?php echo $__env->make('page.message', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>  
    <div class="row">
        <div class="col-md-12">
            <div class="panel-heading">
                    
            </div>   
            <div class="panel-body">   
                
                           
                <table width="100%" class="table table-bordered table-hover" id="visitrecordTable">
                    
                </table>         
                <div class="pull-left">
                    
                </div>
                <div class="pull-right">
                    
                </div>
                
                    <div class="alert text-danger">
                        
                    </div> 
                
            </div>    
            <!-- /.table-responsive -->
        </div>       
        <!-- /.panel-body -->
    </div>
    <!-- /.panel -->    
</div>
<!-- /.col-lg-6 -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>