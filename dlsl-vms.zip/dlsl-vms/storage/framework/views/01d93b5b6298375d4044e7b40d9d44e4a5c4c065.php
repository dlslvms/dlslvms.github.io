    <div class="pull-left input-group form-group">
        <form class="form-inline" autocomplete="off" action="<?php echo e(route('user-management.search')); ?>" method="POST" role="search">
            <?php echo e(csrf_field()); ?>

            <div class="input-group">
                <span class="input-group-btn">
                    <a href="<?php echo e(route('user-management.index')); ?>" class="btn btn-default"><i class="fa fa-lg fa-refresh"></i></a>
                </span>
                <input type="text" class="form-control" name="search" id="searchItem" placeholder="Search..." required>
            </div>
            <div class="input-group">
                <button class="btn btn-info" type="submit" name="filter" id="filter"><i class="fa fa-xs fa-search"></i></button>
            </div>
        </form>
    </div>
    <div class="pull-right">
        <a href="<?php echo e(route('user-management.add')); ?>" class="btn btn-md btn-primary"><i class="fa fa-fw fa-plus-circle"></i> Add New User</a> 
    </div>