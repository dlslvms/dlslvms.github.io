<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
             <h2 class="page-header"><i class="fa fa-search fa-fw"></i>Visitor Profile</h2>
        </div>
    </div>
    <?php echo $__env->make('page.message', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <img src="<?php echo e(asset('storage/uploads/pictures/'.$visitors->picture.'')); ?>" style="width: 150px; height: 150px; float:left; border-radius:50%; margin-right:25px;">
            <h2><?php echo e($visitors->firstname); ?> <?php echo e($visitors->middlename); ?> <?php echo e($visitors->lastname); ?></h2>
        </div>       
        <!-- /.panel-body -->
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>