<div class="hidden-print""pull-left input-group form-group">
    <form class="form-inline" autocomplete="off" action="<?php echo e(route('visitor-record.searchR')); ?>" method="POST" role="filter">
        <?php echo e(csrf_field()); ?>

        <div class=" input-group form-group">
            
                <a href="<?php echo e(route('visitor-record.index')); ?>" class="btn btn-default"><i class="fa fa-lg fa-refresh"></i></a>
            
            
            
        </div>
        <div class="input-group date">
            <span class="input-group-addon"><i class="fa fa-calendar"></i></span>
            <input type="text" class="form-control" id="dateFrom" name="dateFrom" placeholder="From Date" value="<?php echo e(isset($dateFrom) ? $dateFrom : ''); ?>"  />
            <span class="input-group-addon"><i class="fa fa-minus"></i></span>
            <input type="text" class="form-control" id="dateTo" name="dateTo" placeholder="To Date" value="<?php echo e(isset($dateTo) ? $dateTo : ''); ?>"  />
            <span class="input-group-btn">
                <button class="btn btn-info" type="submit" name="filter" id="filter"><i class="fa fa-xs fa-filter"></i></button>    
            </span>
        </div>
        <div class="input-group form-group">
           
        </div>
    </form>
</div>
<div class="pull-right">
    <span class="hidden-print">
        <button onclick="myFunction()"  class="btn btn-md btn-primary"><i class="fa fa-fw fa-plus"></i>Print</button>
            <script>
                function myFunction() 
                {
                    window.print();
                }
            </script>
    </span>
</div>
<br>