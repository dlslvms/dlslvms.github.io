<div class="navbar-default sidebar" role="navigation">
        <div class="sidebar-nav navbar-collapse">
            <ul class="nav" id="side-menu">
                <li class="sidebar-search">
                    <div class="input-group custom-search-form">
                        <input type="text" class="form-control" placeholder="Search...">
                        <span class="input-group-btn">
                        <button class="btn btn-default" type="button">
                            <i class="fa fa-search"></i>
                        </button>
                    </span>
                    </div>
                    <!-- /input-group -->
                </li>
                <li>
                    <a href="<?php echo e(url('dashboard')); ?>"><i class="fa fa-th-large fa-fw"></i> Dashboard</a>
                </li>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isUser')): ?>
                <li>
                    
                </li>
                <li>
                    <a href="<?php echo e(url('visitor-register')); ?>"><i class="fa fa-pencil-square-o fa-fw"></i> Visitor Registration</a>
                    <!-- /.nav-second-level -->
                </li>
                <?php endif; ?>
                <li>
                    <a href="<?php echo e(url('visitor-monitor')); ?>"><i class="fa fa-bullseye fa-fw"></i> Visitor Monitor</a>
                </li>
                
                <li>
                    <a href="#"><i class="fa fa-book fa-fw"></i> Records<span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isAdmin')): ?>
                        <li>
                            <a href="<?php echo e(url('userlog')); ?>"><i class="fa fa-fw fa-th-list"></i> User Logs</a>
                        </li>
                        <li>
                            <a href="<?php echo e(url('visitorlog')); ?>"><i class="fa fa-fw fa-th-list"></i> Visitor Logs</a>
                        </li>
                        <?php endif; ?>
                        
                        <li>
                            <a href="<?php echo e(url('visitor-record')); ?>"><i class="fa fa-fw fa-list-alt"></i> Visitor Records</a>
                        </li>
                        
                    </ul>
                    <!-- /.nav-second-level -->
                </li>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isAdmin')): ?>
                
                <li>
                    <a href=""><i class="fa fa-bar-chart-o fa-fw"></i> Statistics<span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level">
                        <li>
                            <a href="<?php echo e(url('pagestatistic.statistic')); ?>"><i class="fa fa-bar-chart-o fa-fw"></i> Statistics</a>
                        </li>
                         <li>
                            <a href="<?php echo e(url('pagestatistic.frequentvisitor')); ?>"><i class="fa fa-users fa-fw"></i> Frequent Visitor </a>
                        </li> 
                        <li>
                            <a href="<?php echo e(url('pagestatistic.frequentdestination')); ?>"><i class="fa fa-building-o fa-fw"></i> Frequent Destination </a>
                        </li>
                        
                    </ul>
                    <!-- /.nav-second-level -->
                </li> 
                <li>
                    <a href="<?php echo e(url('user-management')); ?>"><i class="fa fa-user fa-fw"></i> User Management</a>                    
                </li>
                <?php endif; ?>
            </ul>
        </div>
        <!-- /.sidebar-collapse -->
    </div>
    <!-- /.navbar-static-side -->
</nav>