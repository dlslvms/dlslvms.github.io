<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h2 class="page-header"><i class="fa fa-list-alt fa-fw"></i>Visitor Record</h2>
        </div>
    </div>
    <?php echo $__env->make('page.message', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>  
    <div class="row">
        <div class="col-md-12">
            <div class="panel-heading">
                    <?php echo $__env->make('pagerecord.searchRecord', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
            </div>   
            <div class="panel-body">   
                <?php if(isset($visitors)): ?>   
                           
                <table width="100%" class="table table-bordered table-hover dataTable" id="recordTable">
                    <?php echo $__env->make('pagerecord.visitor-recordSearchTable', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>                                      
                </table>         
                <?php else: ?>
                    <div class="alert text-danger">
                        <h2><?php echo e($message); ?></h2>
                    </div> 
                <?php endif; ?> 
            </div>    
            <!-- /.table-responsive -->
        </div>       
        <!-- /.panel-body -->
    </div>
    <!-- /.panel -->    
</div>
<!-- /.col-lg-6 -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
    $(document).ready(function() {
        $('#dateFrom').datepicker({
            todayBtn: "linked",
            autoclose: true,
            todayHighlight: true,
            format: 'yyyy-mm-dd'
        });
        $("#dateFrom").datepicker().datepicker("setDate", new Date());
        $('#dateTo').datepicker({
            todayBtn: "linked",
            autoclose: true,
            todayHighlight: true,
            format: 'yyyy-mm-dd'
        });
        $("#dateTo").datepicker().datepicker("setDate", new Date());
    }); 
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>