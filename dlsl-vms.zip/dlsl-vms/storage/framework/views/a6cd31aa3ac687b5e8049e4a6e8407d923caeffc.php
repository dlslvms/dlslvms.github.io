<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h2 class="page-header"><i class="fa fa-fw fa-pencil-square-o"></i>Visitor Registration</h2>
        </div>
    </div>
    <?php echo $__env->make('page.message', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
    <div class="row">
        <div class="">
            <div class="panel panel-default">
                <div class="panel-body">
                    <form enctype="multipart/form-data" class="" autocomplete="off" role="form" action="<?php echo e(route('visitor-register.store')); ?>" method="POST">
                        <?php echo e(csrf_field()); ?>

                        <fieldset>
                            <?php echo $__env->make('pageregister.visitor-registerForm', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                        </fieldset>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>   
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
    // $(document).ready(function () {
    //     $(".text").hide();
    //     $("#registration_type1").click(function () {
    //         $(".text").show();
    //         $(".text1").hide();
    //     });
    //     $(".text1").hide();
    //     $("#registration_type2").click(function () {
    //         $(".text").hide();
    //         $(".text1").show();
    //     });
    // });
    document.getElementById('group_button').addEventListener('click',hideshow);

    function hideshow(e) {
        document.getElementById('hidden-div').style.display = 'block'; 
        this.style.display = 'none';
        e.preventDefault();
    }   
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>