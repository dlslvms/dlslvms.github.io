<thead>
    <tr>
        <th class="text-center" style="width: 5px;">No.</th>
        <bold>
        <th class="text-center" style="width: 70px;">Visitor Name</th>
        <th class="text-center" style="width: 50px;">Destination</th>
        <th class="text-center" style="width: 60px;">Purpose</th>
        <th class="text-center" style="width: 80px;">Time in at</th>
        <th class="text-center" style="width: 80px;">Time out at</th>
        <th class="text-center" style="width: 75px;">Actions</th>
        </bold>
    </tr>
</thead>
<tbody>
    <?php $__currentLoopData = $visitors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $visitor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td class="text-center"><?php echo e($index + $visitors->firstItem()); ?> </td>
        <td class="text-center"><?php echo e($visitor->firstname); ?> <?php echo e($visitor->middlename); ?> <?php echo e($visitor->lastname); ?> </td>
        <td class="text-center"><?php echo e($visitor->destination); ?></td>
        <td class="text-center"><?php echo e($visitor->purpose); ?></td>
        <td class="text-center"><?php echo e($visitor->timein_at ? date('h:i A', strtotime($visitor->timein_at)) : null); ?></td>
        <td class="text-center"><?php echo e($visitor->timeout_at ? date('h:i A', strtotime($visitor->timeout_at)) : null); ?></td>
        <td class="text-center"style="inline-block">
            <a href="<?php echo e(route('visitor-management.edit', ['id' => $visitor->id])); ?>" class="btn btn-xs btn-primary">
                <i class="fa fa-pencil-square-o fa-fw"></i> View
            </a>                                  
            <a href="" class="btn btn-xs btn-primary">
                <i class="fa fa-tag fa-fw"></i> Badge
            </a>                                  
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   
</tbody> 
    