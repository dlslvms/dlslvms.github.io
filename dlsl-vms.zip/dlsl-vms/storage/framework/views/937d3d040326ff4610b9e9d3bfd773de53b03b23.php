<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
            <h2 class="page-header"><i class="fa fa-bar-chart-o fa-fw"></i>Statistics Report</h2>
        </div>
    </div>
    <?php echo $__env->make('page.message', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>   
    <div class="row">
        <div class="col-md-6 col-md-offset-1">
            <div id="curve_chart" style="width:800px; height:500px;"></div>
        </div>
        <!-- /.panel-body -->
    </div>
    <!-- /.panel -->    
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

    

    <script type="text/javascript">
        var analytics = <?php echo $firstname; ?>

        google.charts.load('current', {'packages':['corechart']});
        google.charts.setOnLoadCallback(drawChart);

    function drawChart()
    {
        var data = google.visualization.arrayToDataTable(analytics);
        var options = 
        {
            title : '',
        };
        var chart = new google.visualization.LineChart(document.getElementById('curve_chart'));
        chart.draw(data, options);  
    }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.statistics', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>