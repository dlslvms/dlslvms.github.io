<thead>
    <tr>
        <th class="text-center" style="width: 1%;">No.</th>
        <bold>
        <th style="width: 80px;">First Name</th>
        <th style="width: 80px;">Last Name</th>
        <th class="text-center" style="width: 50px;">User ID</th>
        <th class="text-center" style="width: 50px;">User Type</th>
        <th class="text-center" style="width: 50px;" colspan="2">Login At</th>
        <th class="text-center" style="width: 50px;" colspan="2">Logout At</th>
        
        </bold>
    </tr>
</thead>
<?php
    $countItem = 1;    
?>
<tbody>
        <?php $__currentLoopData = $userlogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $userlog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="text-center"><?php echo e($countItem++); ?></td>
            <td hidden><?php echo e($userlog->user_id); ?></td>
            <td><?php echo e($userlog->firstname); ?></td>
            <td><?php echo e($userlog->lastname); ?></td>
            <td class="text-center"><?php echo e($userlog->user_number); ?></td>
            <td class="text-center"><?php echo e($userlog->user_type); ?></td>
            <td class="text-align" style="width: 30px;"><?php echo e(date('F d, y', strtotime($userlog->login_at))); ?></td>
            <td class="text-align" style="width: 30px;"><?php echo e(date('h:i A', strtotime($userlog->login_at))); ?></td>
            <td class="text-align" style="width: 30px;"><?php echo e($userlog->logout_at ? date('F d, y', strtotime($userlog->logout_at)) : null); ?></td>
            <td class="text-align" style="width: 30px;"><?php echo e($userlog->logout_at ? date('h:i A', strtotime($userlog->logout_at)) : null); ?></td>
            
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody> 
