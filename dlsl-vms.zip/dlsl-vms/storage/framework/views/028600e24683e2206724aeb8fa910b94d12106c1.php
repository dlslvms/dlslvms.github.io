<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
             <h2 class="page-header"><i class="fa fa-user fa-fw"></i>Visitor Profile</h2>
        </div>
    </div>
    <?php echo $__env->make('page.message', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="row">
        <div class="col-md-8 col-md-offset-1 ">   
            <div class="panel panel-success   ">
                <div class="panel-heading">
                    <h3 class="panel-title"><?php echo e($visitors->firstname); ?> <?php echo e($visitors->lastname); ?></h3>
                </div>
                <div class="panel-body">
                    <div class="row">
                        <div class="col-md-7 col-lg-3 " align="center"> <img src="<?php echo e(asset('storage/uploads/pictures/'.$visitors->picture.'')); ?>" style="width: 150px; height: 150px; float:left; border-radius:50%; margin-right:30px;"> </div>
                            <div class=" col-md-9 col-lg-9 "> 
                                <table class="table table-user-information">
                                    <tbody>
                                        <tr>
                                            <td><label>Name</label></td>
                                            <td><?php echo e($visitors->firstname); ?> <?php echo e($visitors->middlename); ?> <?php echo e($visitors->lastname); ?></td>         
                                        </tr>
                                        <tr>
                                            <td><label>Address</label></td>
                                            <td><?php echo e($visitors->address); ?></td>
                                        </tr>
                                        <tr>
                                            <td><label>Type of ID & ID Number</label></td>
                                            <td><?php echo e($visitors->id_type); ?> : <?php echo e($visitors->govid_number); ?></td>
                                        </tr>
                                        <tr>
                                            <td><label>Destination</label></td>
                                            <td><?php echo e($visitors->destination); ?></td>
                                        </tr>
                                        <tr>
                                            <td><label>Purpose</label></td>
                                            <td><?php echo e($visitors->purpose); ?></td>
                                        </tr>
                                        <tr>
                                            <td><label>Destination</label></td>
                                            <td><?php echo e($visitors->destination); ?></td>
                                        </tr>
                                        <tr>
                                            <td><label>Access Card Number</label></td>
                                            <td><?php echo e($visitors->accesscard_number); ?></td>
                                        </tr>
                                        
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
    

<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>