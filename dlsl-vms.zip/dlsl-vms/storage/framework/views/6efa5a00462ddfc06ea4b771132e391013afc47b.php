<?php if(session('StatusAdd')): ?>
<div class="alert alert-success alert-dismissable">
<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
    <p><?php echo e(session('StatusAdd')); ?></p>
</div>
<?php endif; ?>
<?php if(session('StatusDeactivate')): ?>
<div class="alert alert-danger alert-dismissable">
<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
    <p><?php echo e(session('StatusDeactivate')); ?></p>
</div>
<?php endif; ?>    
<?php if(session('StatusEdit')): ?>
<div class="alert alert-success alert-dismissable">
<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
<p><?php echo e(session('StatusEdit')); ?></p>
</div>
<?php endif; ?>
<?php if(session('ErrorEdit')): ?>
<div class="alert alert-danger alert-dismissable">
   <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
    <p><?php echo e(session('ErrorEdit')); ?></p>
</div>
<?php endif; ?>
<?php if(session('Message')): ?>
<div class="alert alert-danger alert-dismissable">
   <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>    
    <p><?php echo e(session('Message')); ?></p>
</div>
<?php endif; ?>
<?php if(session('SearchMessage')): ?>
<div class="alert alert-danger alert-dismissable">
   <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>    
    <p><?php echo e(session('SearchMessage')); ?></p>
</div>
<?php endif; ?>
