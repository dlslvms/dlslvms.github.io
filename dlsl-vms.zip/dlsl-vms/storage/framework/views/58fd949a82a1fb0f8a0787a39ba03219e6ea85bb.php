<?php $__env->startSection('title','Edit'); ?>
<?php $__env->startSection('content'); ?>
<div id="page-wrapper">
    <div class="row">
        <div class="col-lg-12">
             <h2 class="page-header"><i class="fa fa-pencil fa-fw"></i>Edit User</h2>
        </div>
    </div>
    <?php echo $__env->make('page.message', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="row">
        <div class="col-md-10 col-md-offset-1">
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h3 class="panel-title"><label>Edit Form</label></h3>
                </div>
                <?php if(isset($users)): ?>
                <div class="panel-body">
                    <form class="" role="form" method="POST" action="<?php echo e(route('user-management.update', ['id' => $users->id])); ?>">
                        <?php echo e(method_field('PUT')); ?>

                        <?php echo e(csrf_field()); ?>

                        <fieldset>
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <div class="form-group">
                                            <label>Upload Visitor Picture</label>
                                            <input type="file" name="picture">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4 form-group">
                                    <label for="lastname">Last Name</label>
                                    <input class="form-control" name="lastname" id="lastname" type="text" placeholder="" 
                                    value="<?php echo e($users->lastname); ?>">                            
                                </div> 
                                
                                <div class="col-md-4 form-group">
                                    <label for="firstname">First Name</label>
                                    <input class="form-control" name="firstname" id="firstname" type="text" placeholder="" 
                                    value="<?php echo e($users->firstname); ?>">                            
                                </div>
                                
                                <div class="col-md-4 form-group">
                                    <label for="middlename">Middle Name</label>
                                    <input class="form-control" name="middlename" id="middlename" type="text" placeholder="" 
                                    value="<?php echo e($users->lastname); ?>">                            
                                </div>
                                
                                <div class="col-md-4 form-group">
                                    <label for="address">Address</label>
                                    <input class="form-control" name="address" id="address" type="text" placeholder="" 
                                    value="<?php echo e($users->address); ?>">                            
                                </div>
                                
                                <div class="col-md-4 form-group">
                                    <label for="birthday">Birthday</label>
                                    <input class="form-control" name="birthday" id="birthday" type="text" placeholder="" 
                                    value="<?php echo e($users->birthday); ?>">                            
                                </div>
                                
                                <div class="col-md-4 form-group">
                                    <label for="contact_number">Contact Number</label>
                                    <input class="form-control" name="contact_number" id="contact_number" type="text" placeholder="" 
                                    value="<?php echo e($users->contact_number); ?>">                            
                                </div>

                                <div class="col-md-6 form-group">
                                    <label for="user_number">User ID Number</label>
                                    <input class="form-control" name="user_number" id="user_number" type="text" placeholder="" 
                                    value="<?php echo e($users->user_number); ?>">                            
                                </div>  
                                
                                <div class="col-md-6">              
                                    <div class="form-group <?php echo e($errors->has('user_type') ? ' has-error' : ''); ?>">
                                            <br><br><label for="user_type">Access Type</label>
                                            <label class="radio-inline">
                                                <input type="radio" name="user_type" id="user_type" value="admin" <?php echo e($users->user_type == 'admin' ? 'checked' : ''); ?>>Admin                                             
                                            </label>            
                                            <label class="radio-inline">
                                                <input type="radio" name="user_type" id="user_type" value="user" <?php echo e($users->user_type == 'user' ? 'checked' : ''); ?>>Lobby Guard                                            
                                            </label>
                                            <?php if($errors->has('user_type')): ?>
                                                <span class="help-block">
                                                    <strong><?php echo e($errors->first('user_type')); ?></strong>
                                                </span>
                                            <?php endif; ?>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <label for="password">Change Password</label>
                                    <div class="form-group <?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                                        <input class="form-control" placeholder="New Password" name="password" type="password">
                                        <?php if($errors->has('password')): ?>
                                            <span class="help-block">
                                                <strong><?php echo e($errors->first('password')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <label for="password">Confirm Password</label>
                                    <div class="form-group <?php echo e($errors->has('password_confirmation') ? ' has-error' : ''); ?>">
                                        <input class="form-control" placeholder="Confirm New Password" name="password_confirmation" type="password" value="">
                                        <?php if($errors->has('password_confirmation')): ?>
                                            <span class="help-block">
                                                <strong><?php echo e($errors->first('password_confirmation')); ?></strong>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <div class="pull-right">
                                    <button type="submit" class=" btn btn-md btn-success">Save</button>
                                    <a href="<?php echo e(route('visitor-register.index')); ?>" class=" btn btn-md btn-danger">Cancel</a>
                                </div>
                        </fieldset>
                    </form>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>