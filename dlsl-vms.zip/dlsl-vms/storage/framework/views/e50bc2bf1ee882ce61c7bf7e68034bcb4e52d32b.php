<thead>
    <tr>
        <th class="text-center" style="width: 1%;">No.</th>
        <bold>
        <th class="text-center" style="width: 100px;">First Name</th>
        <th class="text-center" style="width: 100px;">Last Name</th>
        <th class="text-center" style="width: 50px;">User ID</th>
        <th class="text-center" style="width: 60px;">User Type</th>
        <th class="text-center" style="width: 80px;">Registered at</th>
        <th class="text-center" style="width: 80px;">Updated at</th>
        <th class="hidden-print" "text-center" style="width: 75px;">Actions</th>
        </bold>
    </tr>
</thead>
<tbody>
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td class="text-center"> <?php echo e($index + $users->firstItem()); ?></td>
        <td><?php echo e($user->firstname); ?></td>
        <td><?php echo e($user->lastname); ?></td>
        <td class="text-center"><?php echo e($user->user_number); ?></td>
        <td class="text-center"><?php echo e($user->user_type); ?></td>
        <td class="text-center"><?php echo e(date("F d, Y", strtotime($user->created_at))); ?></td>
        <td class="text-center"><?php echo e(date("F d, Y", strtotime($user->updated_at))); ?></td>
        <td class="hidden-print" "text-center"style="inline-block">
            <a href="<?php echo e(route('user-management.edit', ['id' => $user->id])); ?>" class="btn btn-xs btn-primary">
                <i class="fa fa-pencil-square-o fa-fw"></i> Edit
            </a> 
            <?php if($user->id != Auth::user()->id): ?>
            <button class="btn btn-xs btn-danger" data-statid="<?php echo e($user->id); ?>" data-statval="1" data-toggle="modal" data-target="#status">
                <i class="fa fa-ban fa-1x"></i> Deactivate
            </button>
            <?php endif; ?>
            <div class="modal fade" id="status" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">                                                
                <div class="modal-dialog">                                                    
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                            <h4 class="modal-title" id="myModalLabel">Deactivation Confirmation</h4>
                        </div>                                                                                                       
                        <form action="<?php echo e(route('user-management.status')); ?>" method="POST">
                            <?php echo e(method_field('PATCH')); ?>

                            <?php echo e(csrf_field()); ?>

                            <div class="modal-body">                                                        
                                    Are you sure you want to deactivate this account?
                                    <input type="hidden" name="status_id" id="stat_id" value="">
                                    <input type="hidden" name="status_value" id="stat_val" value="">
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-default" data-dismiss="modal"><i class="fa fa-times fa-1x"></i> Close</button>
                                <button type="submit" class="btn btn-danger"><i class="fa fa-ban fa-1x"></i> Deactivate</button>
                            </div>                        
                        </form>
                    </div>
                    <!-- /.modal-content -->
                </div>                                           
                <!-- /.modal-dialog -->                                        
            </div>                                         
        </td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   
</tbody> 
    